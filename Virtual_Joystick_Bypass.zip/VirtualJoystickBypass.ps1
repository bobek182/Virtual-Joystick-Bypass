﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

$script:statusForm = $null
$script:prankTimer = $null
$script:capturedBinding = $null
$script:bindingBoxes = @{}

$script:targetProcessEncoded = 'UGxhbmV0U2lkZTJfeDY0'

function Test-TargetApplication {
    try {
        $targetName = [System.Text.Encoding]::UTF8.GetString(
            [System.Convert]::FromBase64String($script:targetProcessEncoded)
        )
        return ($null -ne (Get-Process -Name $targetName -ErrorAction SilentlyContinue | Select-Object -First 1))
    }
    catch {
        return $false
    }
}


function New-Label {
    param([string]$Text, [int]$X, [int]$Y, [int]$W, [int]$H = 23, [switch]$Bold)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.Location = New-Object System.Drawing.Point($X, $Y)
    $l.Size = New-Object System.Drawing.Size($W, $H)
    $l.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    if ($Bold) {
        $l.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
    }
    return $l
}

function Get-KeyDisplayName {
    param([System.Windows.Forms.Keys]$Key)

    $name = $Key.ToString()

    if ($name -match '^D([0-9])$') { return $Matches[1] }
    if ($name -match '^[A-Z]$') { return $name }

    switch ($name) {
        'LControlKey' { return 'Left Ctrl' }
        'RControlKey' { return 'Right Ctrl' }
        'ControlKey'  { return 'Ctrl' }
        'LShiftKey'   { return 'Left Shift' }
        'RShiftKey'   { return 'Right Shift' }
        'ShiftKey'    { return 'Shift' }
        'LMenu'       { return 'Left Alt' }
        'RMenu'       { return 'Right Alt' }
        'Menu'        { return 'Alt' }
        'Return'      { return 'Enter' }
        'Escape'      { return 'Esc' }
        'Back'        { return 'Backspace' }
        'Capital'     { return 'Caps Lock' }
        'Prior'       { return 'Page Up' }
        'Next'        { return 'Page Down' }
        'Snapshot'    { return 'Print Screen' }
        'Scroll'      { return 'Scroll Lock' }
        'Oemtilde'    { return '`' }
        'OemMinus'    { return '-' }
        'Oemplus'     { return '=' }
        'OemOpenBrackets' { return '[' }
        'Oem6'        { return ']' }
        'Oem5'        { return '\' }
        'Oem1'        { return ';' }
        'Oem7'        { return "'" }
        'Oemcomma'    { return ',' }
        'OemPeriod'   { return '.' }
        'OemQuestion' { return '/' }
        default       { return $name }
    }
}

function Show-BindCapture {
    $script:capturedBinding = $null

    $capture = New-Object System.Windows.Forms.Form
    $capture.Text = 'Bind Input'
    $capture.StartPosition = 'CenterParent'
    $capture.FormBorderStyle = 'FixedDialog'
    $capture.MaximizeBox = $false
    $capture.MinimizeBox = $false
    $capture.ClientSize = New-Object System.Drawing.Size(390, 150)
    $capture.KeyPreview = $true
    $capture.Font = New-Object System.Drawing.Font('Segoe UI', 9)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'Press any keyboard key or mouse button.'
    $title.Location = New-Object System.Drawing.Point(20, 20)
    $title.Size = New-Object System.Drawing.Size(350, 30)
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $capture.Controls.Add($title)

    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = 'Supported mouse inputs: Left, Right, Middle, Mouse 4, Mouse 5'
    $hint.Location = New-Object System.Drawing.Point(20, 55)
    $hint.Size = New-Object System.Drawing.Size(350, 25)
    $hint.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $capture.Controls.Add($hint)

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.Location = New-Object System.Drawing.Point(150, 100)
    $cancel.Size = New-Object System.Drawing.Size(90, 28)
    $cancel.Add_Click({ $capture.Close() })
    $capture.Controls.Add($cancel)

    $keyHandler = {
        param($sender, $e)
        $script:capturedBinding = Get-KeyDisplayName $e.KeyCode
        $e.SuppressKeyPress = $true
        $e.Handled = $true
        $capture.Close()
    }
    $capture.Add_KeyDown($keyHandler)

    $mouseHandler = {
        param($sender, $e)
        switch ($e.Button) {
            ([System.Windows.Forms.MouseButtons]::Left)    { $script:capturedBinding = 'Mouse Left' }
            ([System.Windows.Forms.MouseButtons]::Right)   { $script:capturedBinding = 'Mouse Right' }
            ([System.Windows.Forms.MouseButtons]::Middle)  { $script:capturedBinding = 'Mouse Middle' }
            ([System.Windows.Forms.MouseButtons]::XButton1){ $script:capturedBinding = 'Mouse 4' }
            ([System.Windows.Forms.MouseButtons]::XButton2){ $script:capturedBinding = 'Mouse 5' }
            default { return }
        }
        $capture.Close()
    }

    $capture.Add_MouseDown($mouseHandler)
    $title.Add_MouseDown($mouseHandler)
    $hint.Add_MouseDown($mouseHandler)

    [void]$capture.ShowDialog()
    return $script:capturedBinding
}

function Show-PrankScreen {
    $prank = New-Object System.Windows.Forms.Form
    $prank.FormBorderStyle = 'None'
    $prank.WindowState = 'Maximized'
    $prank.StartPosition = 'Manual'
    $prank.TopMost = $true
    $prank.KeyPreview = $true
    $prank.BackColor = [System.Drawing.SystemColors]::Control

    $message = New-Object System.Windows.Forms.Label
    $message.Text = 'Nice try! Get good instead of cheating ;)'
    $message.Dock = 'Fill'
    $message.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $message.Font = New-Object System.Drawing.Font('Segoe UI', 42, [System.Drawing.FontStyle]::Bold)
    $prank.Controls.Add($message)

    $prank.Add_KeyDown({
        param($sender, $e)
        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
            $sender.Close()
        }
    })

    [void]$prank.ShowDialog()
}

function Stop-Session {
    if ($script:prankTimer -ne $null) {
        try { $script:prankTimer.Stop() } catch {}
        try { $script:prankTimer.Dispose() } catch {}
        $script:prankTimer = $null
    }
    if ($script:statusForm -ne $null -and -not $script:statusForm.IsDisposed) {
        try { $script:statusForm.Close() } catch {}
    }
    $script:statusForm = $null
    if ($script:mainStatusLabel -ne $null) {
        $script:mainStatusLabel.Text = 'Status: Ready'
    }
}

function Start-Session {
    Stop-Session

    $script:mainStatusLabel.Text = 'Status: Initializing virtual input session...'

    $script:statusForm = New-Object System.Windows.Forms.Form
    $script:statusForm.Text = 'Virtual Joystick Bypass'
    $script:statusForm.StartPosition = 'CenterScreen'
    $script:statusForm.FormBorderStyle = 'FixedDialog'
    $script:statusForm.MaximizeBox = $false
    $script:statusForm.MinimizeBox = $false
    $script:statusForm.ClientSize = New-Object System.Drawing.Size(430, 215)
    $script:statusForm.TopMost = $true
    $script:statusForm.Font = New-Object System.Drawing.Font('Segoe UI', 9)

    $sTitle = New-Object System.Windows.Forms.Label
    $sTitle.Text = 'Virtual Joystick Bypass - Active'
    $sTitle.Location = New-Object System.Drawing.Point(20, 18)
    $sTitle.Size = New-Object System.Drawing.Size(390, 28)
    $sTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $sTitle.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $script:statusForm.Controls.Add($sTitle)

    $sText = New-Object System.Windows.Forms.Label
    $sText.Text = "Virtual joystick bypass is running.`r`n`r`nKeep this program open. Closing it immediately disables the workaround."
    $sText.Location = New-Object System.Drawing.Point(35, 58)
    $sText.Size = New-Object System.Drawing.Size(360, 82)
    $sText.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $script:statusForm.Controls.Add($sText)

    $stopButton = New-Object System.Windows.Forms.Button
    $stopButton.Text = 'Stop'
    $stopButton.Location = New-Object System.Drawing.Point(170, 160)
    $stopButton.Size = New-Object System.Drawing.Size(90, 30)
    $stopButton.Add_Click({ Stop-Session })
    $script:statusForm.Controls.Add($stopButton)

    $script:statusForm.Add_FormClosed({
        if ($script:prankTimer -ne $null -and $script:prankTimer.Enabled) {
            $script:prankTimer.Stop()
            $script:prankTimer.Dispose()
            $script:prankTimer = $null
        }
    })

    $script:statusForm.Show()
    $script:mainStatusLabel.Text = 'Status: Active'

    # Watch for the target application. Once it is detected, wait two seconds.
    # If it closes during that delay, return to watching and do not show the final screen.
    $script:prankTimer = New-Object System.Windows.Forms.Timer
    $script:prankTimer.Interval = 500
    $script:prankTimer.Tag = 'watch'
    $script:prankTimer.Add_Tick({
        if ($script:prankTimer.Tag -eq 'watch') {
            if (Test-TargetApplication) {
                $script:prankTimer.Stop()
                $script:prankTimer.Interval = 2000
                $script:prankTimer.Tag = 'delay'
                $script:prankTimer.Start()
            }
            return
        }

        if ($script:prankTimer.Tag -eq 'delay') {
            if (-not (Test-TargetApplication)) {
                $script:prankTimer.Stop()
                $script:prankTimer.Interval = 500
                $script:prankTimer.Tag = 'watch'
                $script:prankTimer.Start()
                return
            }

            $script:prankTimer.Stop()
            $script:prankTimer.Dispose()
            $script:prankTimer = $null

            if ($script:statusForm -ne $null -and -not $script:statusForm.IsDisposed) {
                $script:statusForm.Close()
            }
            $script:statusForm = $null
            $script:mainStatusLabel.Text = 'Status: Ready'
            Show-PrankScreen
        }
    })
    $script:prankTimer.Start()
}

# Main window
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Virtual Joystick Bypass'
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.ClientSize = New-Object System.Drawing.Size(700, 750)
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

# -------------------------
# Screen 1: setup / consent
# -------------------------
$page1 = New-Object System.Windows.Forms.Panel
$page1.Dock = 'Fill'
$form.Controls.Add($page1)

$welcomeTitle = New-Object System.Windows.Forms.Label
$welcomeTitle.Text = 'Virtual Joystick Bypass Setup'
$welcomeTitle.Location = New-Object System.Drawing.Point(24, 22)
$welcomeTitle.Size = New-Object System.Drawing.Size(650, 32)
$welcomeTitle.Font = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$page1.Controls.Add($welcomeTitle)

$welcomeText = New-Object System.Windows.Forms.Label
$welcomeText.Text = @'
Virtual Joystick Bypass provides a lightweight virtual joystick reference used to bypass mouse acceleration caused by mixed mouse and joystick input handling.

The next screen lets you set the virtual stick directions, active axes, pitch reference, dead zone and optional keyboard or mouse rebinds.

IMPORTANT: this is an active, session-based workaround. The program must stay open for the bypass to remain active. Closing the main program or stopping the session immediately disables the workaround.

Before continuing, close any other joystick configuration tools using the same virtual device. Normal keyboard and mouse controls are left unchanged unless you assign a rebind in the next step.
'@
$welcomeText.Location = New-Object System.Drawing.Point(28, 78)
$welcomeText.Size = New-Object System.Drawing.Size(640, 315)
$page1.Controls.Add($welcomeText)

$noticeGroup = New-Object System.Windows.Forms.GroupBox
$noticeGroup.Text = 'User Notice'
$noticeGroup.Location = New-Object System.Drawing.Point(28, 410)
$noticeGroup.Size = New-Object System.Drawing.Size(640, 150)
$page1.Controls.Add($noticeGroup)

$noticeText = New-Object System.Windows.Forms.Label
$noticeText.Text = 'Settings are applied only for the current session. Keep the program open while the bypass is active; closing it immediately stops the workaround. Input values must remain within the ranges shown by the control panel.'
$noticeText.Location = New-Object System.Drawing.Point(18, 28)
$noticeText.Size = New-Object System.Drawing.Size(600, 52)
$noticeGroup.Controls.Add($noticeText)

$agree = New-Object System.Windows.Forms.CheckBox
$agree.Text = 'I have read the user notice and want to continue.'
$agree.Location = New-Object System.Drawing.Point(20, 96)
$agree.Size = New-Object System.Drawing.Size(420, 25)
$noticeGroup.Controls.Add($agree)

$ok1 = New-Object System.Windows.Forms.Button
$ok1.Text = 'OK'
$ok1.Location = New-Object System.Drawing.Point(484, 685)
$ok1.Size = New-Object System.Drawing.Size(88, 30)
$ok1.Enabled = $false
$page1.Controls.Add($ok1)

$cancel1 = New-Object System.Windows.Forms.Button
$cancel1.Text = 'Cancel'
$cancel1.Location = New-Object System.Drawing.Point(580, 685)
$cancel1.Size = New-Object System.Drawing.Size(88, 30)
$cancel1.Add_Click({ $form.Close() })
$page1.Controls.Add($cancel1)

$agree.Add_CheckedChanged({ $ok1.Enabled = $agree.Checked })

# -------------------------
# Screen 2: control panel
# -------------------------
$page2 = New-Object System.Windows.Forms.Panel
$page2.Dock = 'Fill'
$page2.Visible = $false
$form.Controls.Add($page2)

$panelTitle = New-Object System.Windows.Forms.Label
$panelTitle.Text = 'Virtual Joystick Bypass'
$panelTitle.Location = New-Object System.Drawing.Point(18, 14)
$panelTitle.Size = New-Object System.Drawing.Size(330, 30)
$panelTitle.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$page2.Controls.Add($panelTitle)

$panelDesc = New-Object System.Windows.Forms.Label
$panelDesc.Text = 'Configure the virtual joystick profile and optional keyboard/mouse rebinds.'
$panelDesc.Location = New-Object System.Drawing.Point(20, 43)
$panelDesc.Size = New-Object System.Drawing.Size(650, 24)
$page2.Controls.Add($panelDesc)

# Virtual joystick setup group
$setupGroup = New-Object System.Windows.Forms.GroupBox
$setupGroup.Text = 'Virtual Joystick Setup'
$setupGroup.Location = New-Object System.Drawing.Point(18, 75)
$setupGroup.Size = New-Object System.Drawing.Size(664, 205)
$page2.Controls.Add($setupGroup)

$comboUp = New-Object System.Windows.Forms.ComboBox
$comboDown = New-Object System.Windows.Forms.ComboBox
$comboLeft = New-Object System.Windows.Forms.ComboBox
$comboRight = New-Object System.Windows.Forms.ComboBox
$comboSpecs = @(
    @{ Label='Up';    Control=$comboUp;    Default='Stick Up' },
    @{ Label='Down';  Control=$comboDown;  Default='Stick Down' },
    @{ Label='Left';  Control=$comboLeft;  Default='Stick Left' },
    @{ Label='Right'; Control=$comboRight; Default='Stick Right' }
)
$cy = 30
foreach ($spec in $comboSpecs) {
    $lab = New-Label $spec.Label 18 $cy 92
    $setupGroup.Controls.Add($lab)
    $c = $spec.Control
    $c.Location = New-Object System.Drawing.Point(118, $cy)
    $c.Size = New-Object System.Drawing.Size(165, 25)
    $c.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$c.Items.Add($spec.Default)
    [void]$c.Items.Add('None')
    $c.SelectedIndex = 0
    $setupGroup.Controls.Add($c)
    $cy += 39
}

$axisLabel = New-Label 'Axis selector' 350 28 90
$setupGroup.Controls.Add($axisLabel)
$checkX = New-Object System.Windows.Forms.CheckBox
$checkY = New-Object System.Windows.Forms.CheckBox
$checkZ = New-Object System.Windows.Forms.CheckBox
$checkX.Text = 'X'; $checkY.Text = 'Y'; $checkZ.Text = 'Z'
$checkX.Location = New-Object System.Drawing.Point(452, 30)
$checkY.Location = New-Object System.Drawing.Point(502, 30)
$checkZ.Location = New-Object System.Drawing.Point(552, 30)
$checkX.Checked = $true; $checkY.Checked = $true; $checkZ.Checked = $true
$checkX.AutoSize = $true; $checkY.AutoSize = $true; $checkZ.AutoSize = $true
$setupGroup.Controls.AddRange(@($checkX, $checkY, $checkZ))

$autoCenter = New-Object System.Windows.Forms.CheckBox
$autoCenter.Text = 'Auto center'
$autoCenter.Location = New-Object System.Drawing.Point(350, 64)
$autoCenter.Size = New-Object System.Drawing.Size(130, 24)
$autoCenter.Checked = $false
$setupGroup.Controls.Add($autoCenter)

$pitchLabel = New-Label 'Auto pitch' 350 103 125
$setupGroup.Controls.Add($pitchLabel)
$autoPitch = New-Object System.Windows.Forms.NumericUpDown
$autoPitch.Location = New-Object System.Drawing.Point(492, 103)
$autoPitch.Size = New-Object System.Drawing.Size(85, 25)
$autoPitch.DecimalPlaces = 2
$autoPitch.Increment = [decimal]0.01
$autoPitch.Minimum = [decimal]-1.00
$autoPitch.Maximum = [decimal]1.00
$autoPitch.Value = [decimal]0.01
$autoPitch.TextAlign = 'Right'
$setupGroup.Controls.Add($autoPitch)
$pRange = New-Label '(-1.00 to 1.00)' 582 103 80
$setupGroup.Controls.Add($pRange)

$dzLabel = New-Label 'Dead zone' 350 145 125
$setupGroup.Controls.Add($dzLabel)
$deadZone = New-Object System.Windows.Forms.NumericUpDown
$deadZone.Location = New-Object System.Drawing.Point(492, 145)
$deadZone.Size = New-Object System.Drawing.Size(85, 25)
$deadZone.DecimalPlaces = 2
$deadZone.Increment = [decimal]0.01
$deadZone.Minimum = [decimal]0.00
$deadZone.Maximum = [decimal]1.00
$deadZone.Value = [decimal]0.01
$deadZone.TextAlign = 'Right'
$setupGroup.Controls.Add($deadZone)
$dzRange = New-Label '(0.00 to 1.00)' 582 145 80
$setupGroup.Controls.Add($dzRange)

# Keyboard / mouse rebind group
$bindGroup = New-Object System.Windows.Forms.GroupBox
$bindGroup.Text = 'Keyboard / Mouse Rebind'
$bindGroup.Location = New-Object System.Drawing.Point(18, 292)
$bindGroup.Size = New-Object System.Drawing.Size(664, 270)
$page2.Controls.Add($bindGroup)

$bindHelp = New-Object System.Windows.Forms.Label
$bindHelp.Text = 'Use Bind, then press a keyboard key or mouse button. Clear restores the binding to None.'
$bindHelp.Location = New-Object System.Drawing.Point(16, 24)
$bindHelp.Size = New-Object System.Drawing.Size(625, 24)
$bindGroup.Controls.Add($bindHelp)

function Add-BindRow {
    param([string]$Name, [string]$Display, [int]$Y)

    $lab = New-Label $Display 18 $Y 145
    $bindGroup.Controls.Add($lab)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = New-Object System.Drawing.Point(170, $Y)
    $box.Size = New-Object System.Drawing.Size(255, 25)
    $box.ReadOnly = $true
    $box.Text = 'None'
    $box.BackColor = [System.Drawing.SystemColors]::Window
    $bindGroup.Controls.Add($box)
    $script:bindingBoxes[$Name] = $box

    $bind = New-Object System.Windows.Forms.Button
    $bind.Text = 'Bind...'
    $bind.Location = New-Object System.Drawing.Point(438, ($Y - 1))
    $bind.Size = New-Object System.Drawing.Size(82, 27)
    $handler = {
        $captured = Show-BindCapture
        if (-not [string]::IsNullOrWhiteSpace($captured)) {
            $box.Text = $captured
        }
    }.GetNewClosure()
    $bind.Add_Click($handler)
    $bindGroup.Controls.Add($bind)

    $clear = New-Object System.Windows.Forms.Button
    $clear.Text = 'Clear'
    $clear.Location = New-Object System.Drawing.Point(530, ($Y - 1))
    $clear.Size = New-Object System.Drawing.Size(82, 27)
    $clearHandler = { $box.Text = 'None' }.GetNewClosure()
    $clear.Add_Click($clearHandler)
    $bindGroup.Controls.Add($clear)
}

Add-BindRow 'PitchUp'   'Pitch Up'    57
Add-BindRow 'PitchDown' 'Pitch Down'  91
Add-BindRow 'YawLeft'   'Yaw Left'    125
Add-BindRow 'YawRight'  'Yaw Right'   159
Add-BindRow 'RollLeft'  'Roll Left'   193
Add-BindRow 'RollRight' 'Roll Right'  227

# Action section
$actionGroup = New-Object System.Windows.Forms.GroupBox
$actionGroup.Text = 'Action'
$actionGroup.Location = New-Object System.Drawing.Point(18, 575)
$actionGroup.Size = New-Object System.Drawing.Size(664, 96)
$page2.Controls.Add($actionGroup)

$runButton = New-Object System.Windows.Forms.Button
$runButton.Text = 'Run'
$runButton.Location = New-Object System.Drawing.Point(22, 31)
$runButton.Size = New-Object System.Drawing.Size(100, 32)
$runButton.Add_Click({ Start-Session })
$actionGroup.Controls.Add($runButton)

$stopMain = New-Object System.Windows.Forms.Button
$stopMain.Text = 'Stop'
$stopMain.Location = New-Object System.Drawing.Point(132, 31)
$stopMain.Size = New-Object System.Drawing.Size(100, 32)
$stopMain.Add_Click({ Stop-Session })
$actionGroup.Controls.Add($stopMain)

$resetButton = New-Object System.Windows.Forms.Button
$resetButton.Text = 'Reset'
$resetButton.Location = New-Object System.Drawing.Point(242, 31)
$resetButton.Size = New-Object System.Drawing.Size(100, 32)
$actionGroup.Controls.Add($resetButton)

$script:mainStatusLabel = New-Object System.Windows.Forms.Label
$script:mainStatusLabel.Text = 'Status: Ready'
$script:mainStatusLabel.Location = New-Object System.Drawing.Point(375, 34)
$script:mainStatusLabel.Size = New-Object System.Drawing.Size(250, 28)
$script:mainStatusLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$actionGroup.Controls.Add($script:mainStatusLabel)

$keepOpenLabel = New-Object System.Windows.Forms.Label
$keepOpenLabel.Text = 'Keep this program open while Status is Active. Closing it immediately stops the bypass.'
$keepOpenLabel.Location = New-Object System.Drawing.Point(22, 65)
$keepOpenLabel.Size = New-Object System.Drawing.Size(610, 22)
$keepOpenLabel.Font = New-Object System.Drawing.Font('Segoe UI', 8.5, [System.Drawing.FontStyle]::Bold)
$actionGroup.Controls.Add($keepOpenLabel)


$backButton = New-Object System.Windows.Forms.Button
$backButton.Text = '< Back'
$backButton.Location = New-Object System.Drawing.Point(388, 690)
$backButton.Size = New-Object System.Drawing.Size(88, 30)
$page2.Controls.Add($backButton)

$cancel2 = New-Object System.Windows.Forms.Button
$cancel2.Text = 'Cancel'
$cancel2.Location = New-Object System.Drawing.Point(580, 690)
$cancel2.Size = New-Object System.Drawing.Size(88, 30)
$cancel2.Add_Click({ Stop-Session; $form.Close() })
$page2.Controls.Add($cancel2)

$ok2 = New-Object System.Windows.Forms.Button
$ok2.Text = 'OK'
$ok2.Location = New-Object System.Drawing.Point(484, 690)
$ok2.Size = New-Object System.Drawing.Size(88, 30)
$ok2.Add_Click({
    [System.Windows.Forms.MessageBox]::Show(
        'Configuration values are stored for the current session. Press Run to activate the bypass, then keep this program open for the workaround to remain active.',
        'Configuration Saved',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
})
$page2.Controls.Add($ok2)

function Reset-Defaults {
    $comboUp.SelectedIndex = 0
    $comboDown.SelectedIndex = 0
    $comboLeft.SelectedIndex = 0
    $comboRight.SelectedIndex = 0
    $autoCenter.Checked = $false
    $checkX.Checked = $true
    $checkY.Checked = $true
    $checkZ.Checked = $true
    $autoPitch.Value = [decimal]0.01
    $deadZone.Value = [decimal]0.01
    foreach ($b in $script:bindingBoxes.Values) { $b.Text = 'None' }
    Stop-Session
}

$resetButton.Add_Click({ Reset-Defaults })

$ok1.Add_Click({
    $page1.Visible = $false
    $page2.Visible = $true
    $page2.BringToFront()
})

$backButton.Add_Click({
    Stop-Session
    $page2.Visible = $false
    $page1.Visible = $true
    $page1.BringToFront()
})

$form.Add_FormClosing({ Stop-Session })

[void][System.Windows.Forms.Application]::Run($form)
