Option Explicit
Dim shell, fso, basePath, psFile, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
basePath = fso.GetParentFolderName(WScript.ScriptFullName)
psFile = basePath & "\VirtualJoystickBypass.ps1"
command = "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & psFile & """"
shell.Run command, 0, False
