@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0VirtualJoystickBypass.ps1"
endlocal
